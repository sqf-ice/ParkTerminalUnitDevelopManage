#encoding:utf-8
from kcht_complex_etc.ui import kcht_clpx_etc_res
