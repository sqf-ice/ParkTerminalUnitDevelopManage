#encoding:utf-8
'''工具组件'''