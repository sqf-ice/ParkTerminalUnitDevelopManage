#encoding:utf-8

class TSStubMock:
    pass



TSStub = TSStubMock()

