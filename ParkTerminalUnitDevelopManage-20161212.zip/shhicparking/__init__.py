from util.paramutil import ParamHolder
from util.dateutil import nowStr

SESSION = ParamHolder()
SESSION["tollCollectorName"] = None
